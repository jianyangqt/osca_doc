//
//  l2_enet.hpp
//  osc
//
//  Created by Futao Zhang on 5/11/2018.
//  Copyright © 2018 Futao Zhang. All rights reserved.
//

#ifndef l2_enet_hpp
#define l2_enet_hpp

#include "l1_stat.hpp"

namespace ELNET{
    
}
#endif /* l2_enet_hpp */
