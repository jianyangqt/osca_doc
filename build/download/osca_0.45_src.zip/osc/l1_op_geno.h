//
//  l1_op_geno.h
//  osc
//
//  Created by Futao Zhang on 31/03/2016.
//  Copyright (c) 2016 Futao Zhang. All rights reserved.
//

#ifndef __osc__l1_op_geno__
#define __osc__l1_op_geno__

#include "l0_io.h"
extern void _calc_ld(double* ld,float* snpData,int rsize,int csize);

#endif /* defined(__osc__l1_op_geno__) */
