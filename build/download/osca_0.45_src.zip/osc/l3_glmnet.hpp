//
//  l3_glmnet.hpp
//  osc
//
//  Created by Futao Zhang on 6/11/2018.
//  Copyright © 2018 Futao Zhang. All rights reserved.
//

#ifndef l3_glmnet_hpp
#define l3_glmnet_hpp

#include "l2_enet.hpp"

namespace ELNET{
    
}


#endif /* l3_glmnet_hpp */
